# encoding: UTF-8 
# Autores: Irma Gómez, Victor Curiel, Francisco Arenas 
# Menú de proyecto

def userInput():
    print('''
    ---------------------------------------------------
    PROYECTO SEGUNDO PARCIAL (ALGORITMOS ORDENAMIENTO):
        1. Probar Bucket Sort
        2. Probar Insertion Sort
        3. Probar Bubble Sort 
        4. Probar Quick Sort 
        5. Probar Radix Sort
        6. Probar Merge Sort
        7. Conocer a los autores del proyecto
        0. Salir
    ---------------------------------------------------
    ''')
    opcion = int(input('¿Qué desea hacer? '))
    return opcion

def autores():
    print('''
    Autor:            Carrera:   Matrícula:
    Irma Gómez         (ITI)      A01747743
    Victor Curiel      (ISC)      A01747245
    Francisco Arenas   (ISC)      A01369122
    ''')

def lecturaArchvo(archivo):
    lectura = open(archivo, 'r')
    contenido = lectura.read()
    contenido = contenido.replace("(","")
    contenido = contenido.replace("\n","")
    x = contenido.split(")")
    return x

def creacionLista(archivo):
    x = lecturaArchvo(archivo)
    lista=x[0].split(",")
    lista=list(map(int,lista))
    return lista

# Función main() con implementación de menú
def main():
    opcion = userInput()
    while opcion != 0:
        if opcion == 1:
            archivo = input("Escriba el nombre del archivo con extensión .txt: ")
            lista = creacionLista(archivo)
            print("\nLa lista a arreglar es: ", lista)
            print("\n--Inicia ordenamiento--\n")
            from BucketSort import bucketSort
            bucketSort(lista)
            
        elif opcion == 2:
            archivo = input("Escriba el nombre del archivo con extensión .txt: ")
            lista = creacionLista(archivo)
            print("\nLa lista a arreglar es: ", lista)
            print("\n--Inicia ordenamiento--\n")
            from InsertionSort import insertionSort
            insertionSort(lista)
            print("--Ordenamiento Finalizado--")
            print(lista)
            
        elif opcion == 3:
            archivo = input("Escriba el nombre del archivo con extensión .txt: ")
            lista = creacionLista(archivo)
            print("\nLa lista a arreglar es: ", lista)         
            print("\n--Inicia ordenamiento--\n")
            from BubbleSort import bubbleSort
            bubbleSort(lista)
            print("\nLa lista arreglada es", lista)
            
        elif opcion == 4:
            archivo = input("Escriba el nombre del archivo con extensión .txt: ")
            lista = creacionLista(archivo)
            print("\nLa lista a arreglar es: ", lista)         
            print("\n--Inicia ordenamiento--\n")
            from QuickSort import quickSort
            quickSort(lista,0,len(lista)-1)
            print("--Ordenamiento Finalizado--")
            print(lista)
          
        elif opcion == 5:
            from RadixSort import detectarBase
            from RadixSort import radixSort
            archivo = input("Escriba el nombre del archivo con extensión .txt: ")
            lista = creacionLista(archivo)
            base = detectarBase(lista)
            print("\nLa lista a arreglar es: ", lista)
            print("\nLa lista arreglada es: ", radixSort(lista, base))
            
        elif opcion == 6:
            from MergeSort import mergeSort
            archivo = input("Escriba el nombre del archivo con extensión .txt: ")
            lista = creacionLista(archivo)
            print("\nLa lista a arreglar es: ", lista)
            print("\nLa lista arreglada es: ", mergeSort(lista))
            
        elif opcion == 7:
            autores()

        else: 
            print("\nOpción no disponible!")
            
        opcion = userInput()
# Llamada al main        
main()