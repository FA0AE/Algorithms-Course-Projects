# encoding: UTF-8 
# Autores: Irma GÃ³mez, Victor Curiel, Francisco Arenas 
# Algoritmos de Ordenamiento

def particion(arr,min,max):
    menoresIndex=min
    pivote=arr[max]
    print("Pivote: ",pivote)
    
    for num in range (min,max+1):
        if(arr[num]<=pivote):
            arr[menoresIndex],arr[num]=arr[num],arr[menoresIndex]
            print(menoresIndex)
            menoresIndex+=1
            print(arr)
            
    print(arr,"\n")
    
    return menoresIndex-1


def quickSort(arr,min,max):
    
    if min<max:
       
        base=particion(arr,min,max)
    
        quickSort(arr,min,base-1)   #derecha
        quickSort(arr,base+1,max)   #izquierda
    
    return arr

A=[1,5,3,6,2,7,2]
quickSort(A,0,len(A)-1)