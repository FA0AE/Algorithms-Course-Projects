# encoding: UTF-8 
# Autores: Irma Gómez, Victor Curiel, Francisco Arenas 
# Algoritmos de Ordenamiento

def bubbleSort(lista):
    cont=1
    for i in range (len(lista)-1, 0, -1):
        print("\nIteración: ", cont)
        print ("\n",lista)
        cont += 1
        for j in range (i):
            if lista[j]>lista[j+1]:
                lista[j], lista[j+1] = lista[j+1],lista[j]
            
    return lista


A=[0,4,7,2,1]
bubbleSort(A)
