# encoding: UTF-8 
# Autores: Irma Gómez, Victor Curiel, Francisco Arenas 
# Algoritmos de Ordenamiento

def bucketSort(arr):
    min=arr[0]
    max=arr[0]
    for i in range(len(arr)):
        if arr[i]>max:
            max=arr[i]
        if arr[i]<min:
            min=arr[i]
    if min<=0:
        lista=[0]*(max-min+1),[0]*(max-min+1)
    else:
        lista=[0]*max,[0]*max
        min=1
        
    for i in arr:
        print("Valor a agregar: ",i)
        lista[0][i-min]=i
        lista[1][i-min]=lista[1][i-min]+1 
        print("\n",lista[0])
        print("\n",lista[1])
        print("----------------------------------------------------------------------------")
    arrOrd=[]
    for i in range(1,len(lista[0])+1):
        if(lista[1][i-1]!=0):
            for j in range(lista[1][i-1]):
                arrOrd.append(lista[0][i-1])
    print("Arreglo ordenado: ",arrOrd)