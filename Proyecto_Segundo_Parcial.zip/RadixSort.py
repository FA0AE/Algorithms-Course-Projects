# encoding: UTF-8 
# Autores: Irma Gómez, Victor Curiel, Francisco Arenas 
# Implementación de Radix Sort 
import math

def detectarBase(lista):
    maximoValor = max(lista)
    digitosIndividuales = [int(digito) for digito in str(maximoValor)]
    base = 0

    if(len(digitosIndividuales) < 2):
        base += 10
    elif(len(digitosIndividuales) == 2):
        base += 100
    elif(len(digitosIndividuales) == 3):
        base += 1000
    elif(len(digitosIndividuales) == 4):
        base += 10000
    elif(len(digitosIndividuales) == 5):
        base += 100000
    elif(len(digitosIndividuales) == 6):
        base += 1000000
    
    return base

def countingSort(lista, base):
    listaInput = lista
    listaOutput = [0] * len(listaInput) 
    listaTemporal = [0] * base  
    iterador = 1           
    
    for numero in listaInput:
        listaTemporal[numero] += 1
    # [1, 0, 6,..., k]  -> Se dice cuantas veces un número se ha repetido
    # .................... k = valores máximo debido a la base

    while(iterador < len(listaTemporal)):
        listaTemporal[iterador] = listaTemporal[iterador] + listaTemporal[iterador - 1]
        iterador += 1
    # [1, 1, 7,..., k + k-1] -> Se suman los valores de la lista temporal 
    # .......................... para saber el indice de la lista output
    
    for numero in reversed(listaInput):
        listaTemporal[numero] = listaTemporal[numero] - 1
        listaOutput[listaTemporal[numero]] = numero
        print('\nHaciendo CountingSort como subrutina: ', listaOutput,"\n")
    # [0, 1, 2, 2,..., n] -> Se colocan los numeros, empezando del último, 
    # ...................... de la lista input a la lista output
    # ...................... n = longitud de la lista input 

    return listaOutput

def radixSort(lista, base):
    listaArreglada = lista

    k = max(lista)
    # Se obtiene el valor maximo k del arreglo con el fin de 
    # poder obtener el valor d de la complejidad O(d(n+b))

    d = int(math.floor(math.log(k, base) + 1))
    print('Valor d: ', d)
    # d es el rango de datos individuales que se revisaran
    # la fórmula de 'd' es propia del algoritmo

    for i in range(d):
        listaArreglada = countingSort(listaArreglada, base)
    # se recorre cada rango de datos individuales y se usa 
    # countingSort() como subrutina del algoritmo 

    base = detectarBase(lista)
    print("----------------------------------------------------------------------------")
    return listaArreglada
