# encoding: UTF-8 
# Autores: Irma Gómez, Victor Curiel, Francisco Arenas 
# Algoritmos de Ordenamiento

def insertionSort(arr):
    for n in range(1,len(arr)):
        valorComparar=arr[n]
        print("Valor a ordenar:",valorComparar)
        for m in range(n,-1,-1):
            if(valorComparar<arr[m]):
                arr[m],arr[m+1]=arr[m+1],arr[m]
        print(arr,"\n")
        

