# encoding: UTF-8 
# Autores: Irma Gómez, Victor Curiel, Francisco Arenas 
# Implementación de Merge Sort 

def mergeSort(lista):
    mitadLista = (len(lista) // 2)

    # Definición de casos
    print('Separando la lista: ', lista)
    if ( (len(lista)) > 1 ):
        mitadIzquierda = lista[:mitadLista]
        mitadDerecha = lista[mitadLista:]
        # Se separan las listas en mitades

        mitadIzquierda = mergeSort(mitadIzquierda)
        mitadDerecha = mergeSort(mitadDerecha)
        # Se hace la llamada recursiva para cada mitad.
        # Se iguala cada mitad al método con el fin de poder 
        # Trabajar con ellas como 'listas' en el paso merge 
        print("-----------------------------------------------------------------------")
        return merge(mitadIzquierda, mitadDerecha)
        # Se regresa el proceso de juntar y de ordenar la lista
    else:            
        print("-----------------------------------------------------------------------")                   
        return lista    
        # La lista tiene solamente un elemento o ninguno 

def merge(mitadIzquierda, mitadDerecha):
    listaOrdenada = []
    
    while ( 0 < len(mitadIzquierda) and 0 < len(mitadDerecha) ):
        if( mitadIzquierda[0] < mitadDerecha[0] ):
            listaOrdenada.append( mitadIzquierda[0] )
            del mitadIzquierda[0]
        else:
            listaOrdenada.append( mitadDerecha[0] )
            del mitadDerecha[0]

    while ( len(mitadIzquierda) > 0 ):
        listaOrdenada.append( mitadIzquierda[0] )
        del mitadIzquierda[0]
    
    while ( len(mitadDerecha) > 0 ):
        listaOrdenada.append( mitadDerecha[0] )
        del mitadDerecha[0]

    print('Haciendo el merge: ', listaOrdenada)
    return listaOrdenada
